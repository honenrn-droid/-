package kr.radio.tbnjeju;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout home;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView label(String text, int size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(Color.rgb(25, 35, 45));
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(25);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 105, 75)));
        b.setMinHeight(92);
        return b;
    }

    private void showHome() {
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setGravity(Gravity.CENTER);
        home.setPadding(28, 36, 28, 36);
        home.setBackgroundColor(Color.rgb(250, 248, 239));

        TextView title = label("제주 라디오", 34);
        TextView frequency = label("TBN 제주교통방송  ·  FM 105.5", 21);
        TextView guide = label("아래 버튼을 누르면
공식 방송 듣기 화면이 열립니다.", 20);

        Button play = bigButton("▶  라디오 듣기");
        play.setOnClickListener(v -> openRadio());

        Button homeButton = bigButton("처음 화면");
        homeButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(80, 90, 105)));
        homeButton.setOnClickListener(v -> showHome());

        home.addView(title, new LinearLayout.LayoutParams(-1, 100));
        home.addView(frequency, new LinearLayout.LayoutParams(-1, 90));
        home.addView(guide, new LinearLayout.LayoutParams(-1, 130));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 100);
        p.setMargins(0, 24, 0, 18);
        home.addView(play, p);
        setContentView(home);
    }

    private void openRadio() {
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("https://www.tbn.or.kr/");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            showHome();
        }
    }
}
